var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/client/types/IconTypes.ts
__export(exports, {
  IconTypes: () => IconTypes
});
var IconTypes;
(function(IconTypes2) {
  IconTypes2[IconTypes2["ChatBox"] = 1] = "ChatBox";
  IconTypes2[IconTypes2["Email"] = 2] = "Email";
  IconTypes2[IconTypes2["AddFriendRequest"] = 3] = "AddFriendRequest";
  IconTypes2[IconTypes2["RightJumpingArrow"] = 7] = "RightJumpingArrow";
  IconTypes2[IconTypes2["RPIcon"] = 8] = "RPIcon";
  IconTypes2[IconTypes2["MoneyIcon"] = 9] = "MoneyIcon";
})(IconTypes || (IconTypes = {}));
